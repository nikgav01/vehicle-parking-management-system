package com.car.parking.booking.services;

import com.car.parking.booking.entities.Rating;

public interface RatingService {

    Rating save(Rating rating);

}
