package com.car.parking.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarParkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarParkingApplication.class, args);
	}

}
