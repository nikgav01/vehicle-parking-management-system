package com.licenta.voinescuvlad.voinescuvlad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoinescuvladApplicationTests {

	@Test
	void contextLoads() {
	}

}
